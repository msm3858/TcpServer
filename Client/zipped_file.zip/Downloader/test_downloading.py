import logging
import os
import sys
import unittest
import urllib
import urllib.request
import uuid

# Set root path.
home_dir = '/home/msm/PycharmProjects/4chanWebScrapper'
sys.path.append(home_dir)

# Import local modules.
from Database.database_wrapper import DatabaseEngine
from Database.database_handler import *
from Downloader.database_scrapper import Scrapper4Chan

separator = '*' * 80


class ExperimentalDatabaseBuilderTest(unittest.TestCase):
    def setUp(self):
        logging.info(separator)
        self.db_directory = '/home/msm/PycharmProjects/4chanWebScrapper/Database/Test'
        self.db_filename = f'test_all.sqlite'
        self.db_path = f'{self.db_directory}/{self.db_filename}'
        self.database_engine = DatabaseEngine(database_type='sqlite',
                                              path_to_database_file=self.db_path)
        self.database_engine.set_engine()
        self.database = DatabaseHandler(self.database_engine.get_engine())
        self.database.create_session()
        self.database.build()
        self.database.build_all_dictionaries()
        self.scrapper = Scrapper4Chan(self.database)

    def tearDown(self):
        self.scrapper = None
        self.database = None
        self.database_engine = None

    def test_find_posts_and_media_from_thread(self):
        logging.info("Test finding posts and media from thread..")
        self.scrapper.set_section('gif')
        self.scrapper.set_headers()
        self.scrapper.set_section_requests()
        self.scrapper.find_and_create_threads_from_section_requests()
        forbidden_words = self.database.get_forbidden_words_for_section(self.scrapper.get_section())
        threads = self.scrapper.get_section_threads()

        for thread in threads:
            self.scrapper.find_and_create_posts_and_media_from_thread(thread)
            self.assertTrue(thread.title, f"Title is not set for this thread[{thread}].")
            for forbidden_word in forbidden_words:
                if thread.title.find(forbidden_word) > (-1):
                    self.assertTrue(thread.is_forbidden,
                                    f"Thread is not forbiddena [thread_id={thread.id}, thread_title={thread.title}, founded forbidden word={forbidden_word}].")
            self.assertEqual(thread.title, thread.title.upper(),
                             f"Thread in database is not uppercased [Thread_id={thread.id}, Thread_title={thread.title}].")


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    unittest.main()
