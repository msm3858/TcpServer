from argparse import ArgumentParser
import logging
import os


def parse_args():
    parser = ArgumentParser()
    parser.add_argument("-d", "--db_file", dest="database_filename", default='basicDB.sqlite',
                        help="Relative path to database file.", metavar="DATABASE_FILE")
    parser.add_argument("-t", "--db_type", dest="database_type", default='sqlite',
                        help="Type of used database.", metavar="DATABASE_TYPE")
    parser.add_argument("-b", "--build_directories", type=bool, dest="do_build_dictionaries",
                        default=True, help="Create database dictionaries.", metavar="[True/False]")
    parser.add_argument("-s", "--short_names", metavar="[SHORT_NAMES]", default=['b'], dest='short_names',
                        type=str, nargs='+', help="Pass table of short names of categories")
    parser.add_argument("-c", "--executor_class", dest="executor_class", default='CommonExecutor',
                        help="Set kind of executor. "
                             "[CommonExecutor, "
                             "DownloadExecutor, "
                             "FindNewThreadsExecutor, "
                             "FindNewPostsAndMediasExecutor]",
                        metavar="KIND_EXECUTOR")
    return parser.parse_args()


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    logging.info("Starting...")
    args = parse_args()
    logging.info(f"db_path = {os.path.join(os.getcwd(), 'Database', args.database_filename)}")
    logging.info(f"db_type = {args.database_type}")
    logging.info(f"build_directories = {args.do_build_dictionaries}")
    logging.info(f"short_names = {args.short_names}")
    logging.info(f"executor_class = {args.executor_class}")

    logging.info("Exiting...")
