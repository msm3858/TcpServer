import os
import logging

def create_sqlite_db_file(database_path):
    logging.info(f'Checking if database already exists in: {database_path}...')
    print('*' * 40)
    if not os.path.isfile(f'{database_path}'):
        logging.info('Database file does not exists.\n Creating file...')
        os.makedirs(f'sqlite3 {database_path}')
        logging.info(f'Database created in path: {database_path}')
        return database_path
    else:
        logging.info('Database already exists. Skipping...')
        return database_path

create_sqlite_db_file('/home/msm/PycharmProjects/4chanWebScrapper/Database/basicDB.db')

os.listdir('/home/msm/PycharmProjects/4chanWebScrapper/Database/')

DATABASE_ENGINE = {
    'sqlite': {
        'connection_string': 'sqlite:////{DB}',
    },
    'postgres': {
        'connection_string': 'postgres://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}',
    }
}