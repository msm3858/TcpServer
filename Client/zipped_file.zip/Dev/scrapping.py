from requests import get
from requests.exceptions import RequestException
from contextlib import closing
from bs4 import BeautifulSoup

# def simple_get(url):
#     """
#     Attempts to get the content at 'url' by making an HTTP GET request.
#     If the content-type of response is some kind of HTML/XML, retuirn the text content, otherwise return None.
#     """
#     try:
#         with closing(get(url, stream=True)) as resp:
#             if is_good_response(resp):
#                 return resp.content
#             else:
#                 return None
#
# def is_good_response(resp):
#     """
#     Returns True if the response seems to be HTML, False otherwise.
#     """
#     content_type = resp.headers['Content-Type'].lower()
#     return (resp.status_code == 200
#             and content_type is not None
#             and content_type.find('html') > -1)


import urllib.request
from bs4 import BeautifulSoup
import re

# section declaration
SECTION = {
    'Photography': {
        'short_name': 'p',
         'category': 'not_adult'
    },
}
# pages limit
PAGES = [''] + [str(i) for i in range(2, 11)]

# array for topics in section
TOPICS_IN_SECTION = []

section = SECTION['Photography']

# url declaration of main site
url = f'http://boards.4channel.org/{section["short_name"]}'

# open page
page = urllib.request.urlopen(url)

# url read
soup = BeautifulSoup(page)

# read title of page
title = soup.title.string
# TODO: add title to dict of all links



# read all links from page
all_links = soup.find_all("a")

# check each link from page
for link in all_links:
    link_to_topic = ''
    link_destination = link.get("href")

    # pattern for checking link

    pattern = f'/{section["short_name"]}/(thread)/(\d*)#(\S*)'

    # check if link matches pattern
    regex_check = re.match(pattern, link_destination)
    if regex_check:
        print ('*' * 40)
        print(link_destination)
        link_to_topic = str(f'{url}/{regex_check.groups()[0]}/{regex_check.groups()[1]}')
        if link_to_topic not in TOPICS_IN_SECTION:
            TOPICS_IN_SECTION.append(link_to_topic)
        print (link_to_topic)
        print (regex_check.groups())

print ('*' * 40)
print (len(TOPICS_IN_SECTION))
for topic in TOPICS_IN_SECTION:
    print(topic)


all_op_posts = soup.find_all('div', class_='postContainer opContainer')
all_reply_posts = soup.find_all('div', class_='postContainer replyContainer')

# <div class="postContainer opContainer"
# <div class="postContainer replyContainer"

link_to_thread = 'http://boards.4channel.org/an/thread/2965278'
# link_to_thread = 'http://boards.4channel.org/an/thread/2965278#12315156'
page = urllib.request.urlopen(link_to_thread)
soup = BeautifulSoup(page)
op_post = soup.find('div', class_='postContainer opContainer')


post = soup.find('div', class_='postContainer opContainer')
post.find('blockquote')
post.find('blockquote').get_text()

link_to_image = '//i.4cdn.org/an/1552664547624.jpg'

section = 'an'
for link in  op_post.find_all('a'):
    link_to_image = link.get('href')
    media_pattern = f'//i.4cdn.org/{section}/(\S+).{1}(\S+)'
    if re.match(media_pattern, link_to_image):
        full_link_to_image = f'https:{link_to_image}'

link_to_thread = 'http://boards.4chan.org/gif/thread/14691486/turning-gf-into-a-slut'

reply_post = soup.find_all('div', class_='postContainer replyContainer')[17]
for link in reply_post.find_all('a'):
    link_to_image = link.get('href')
    print(link_to_image)

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1)'}
link_to_thread = 'http://boards.4chan.org/gif/thread/14691486/turning-gf-into-a-slut?data-cmd=ok-disc'
req = urllib.request.Request(url=link_to_thread, headers=headers)

page = urllib.request.urlopen(req)
soup = BeautifulSoup(page)

soup = soup,
thread = thread,
type_of_element = ''            # div
class_of_element = ''           # postContainer opContainer, postContainer replyContainer
class_of_inner_element = ''     # post op, post reply
type_of_element = ''            # a
is_subject_to_set = ''          # True, False

